var prices = document​.getElementsByClassName(​'productPrice'​);
var quantity = document​.getElementsByClassName(​'productQuantity'​);
var subtotals = document.getElementsByClassName('subTotal');
var total = document.getElementsByClassName('totalCost');

function updateTable(){
    console.log(prices);
}